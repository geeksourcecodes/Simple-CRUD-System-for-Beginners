<?php
/* Web Developer: Paolo Jon B. Caraig - Email Address: paolojoncaraig@gmail.com */
$conn = mysqli_connect("localhost","root","pijey10","crud");
if(!$conn){
die("Database Connection Failed!");
}
?>